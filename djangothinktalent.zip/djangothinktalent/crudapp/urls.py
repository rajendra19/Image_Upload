from django.urls import path
from crudapp import views

urlpatterns = [
    # url for crud oporation
    path('image/', views.ImageListCreateView.as_view(), name='image-list-create'),
    path('image/<int:pk>/', views.ImageRetrieveUpdateDestroyView.as_view(), name='image-retrieve-update-destroy'),

    #Define a URL for the render_image view
    path('images/render/<str:url>/', views.render_image),

    #Define a URL for uploading image
    path('images/upload/', views.ImageUpload.as_view()),

    #difine a url for listing all images
    path('list/images/',views.list_images),

    #define a url for rendering an image from the folder
    path('render_uploaded_image/',views.render_uploaded_image),
]
