
from django.http import HttpResponse
from rest_framework import generics
from crudapp.models import Image
from crudapp.serializers import ImageSerializer
from djangothinktalent import settings


class ImageListCreateView(generics.ListCreateAPIView):
    queryset = Image.objects.all()
    serializer_class = ImageSerializer

class ImageRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Image.objects.all()
    serializer_class = ImageSerializer



#Define a view for rendering images from public links
from django.http import HttpResponse
from django.contrib.sites import requests

def render_image(request, image_url):
    image_data = requests.get(image_url).content
    return HttpResponse(image_data, content_type='image/jpeg')


# Create a view for uploading images
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import ImageSerializer

class ImageUpload(APIView):
    parser_classes = [MultiPartParser, FormParser]

    def post(self, request, format=None):
        serializer = ImageSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        else:
            return Response(serializer.errors, status=400)




# Define a view for listing all images in a folder related to the application
import os
from django.http import JsonResponse

def list_images(request):
    image_dir = os.path.join(settings.MEDIA_ROOT, 'images')
    images = os.listdir(image_dir)
    return JsonResponse({'images': images})

# Create a view for rendering an image from the folder
def render_uploaded_image(request, image_name):
    image_path = os.path.join(settings.MEDIA_ROOT, 'images', image_name)
    with open(image_path, 'rb') as f:
        image_data = f.read()
    return HttpResponse(image_data, content_type='image/jpeg')
